import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AppBar, Box, Divider, Drawer, IconButton,
  List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  styled, Toolbar, Tooltip, Typography, Button
} from '@mui/material';
import logo from '/src/assets/logocvs1.jpg';


//import { MenuOpen } from '@mui/icons-material';
import HomeWorkIcon from '@mui/icons-material/HomeWork';
import ListAltIcon from '@mui/icons-material/ListAlt';
import PostAddIcon from '@mui/icons-material/PostAdd';
import DashboardIcon from '@mui/icons-material/SpaceDashboard';
import LockIcon from '@mui/icons-material/Lock';
import LogoutIcon from '@mui/icons-material/Logout';
import PersonPinIcon from '@mui/icons-material/PersonPin';
//import logo from '/src/assets/imageLogo1.png';
import { AuthContext } from '/src/context/AuthContext';


// Estilos
const DRAWER_WIDTH = 240;
const PRIMARY_COLOR = '#626567';
const HOVER_COLOR = 'PowderBlue';
const APP_COLOR = '#008FD1'

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

const MenuItemButton = styled(ListItemButton)({
  borderRadius: '12px',
  '&:hover': {
    backgroundColor: HOVER_COLOR,
  },
});

// Menú completo (solo para usuarios autenticados)
const menuItems = [
  { text: 'Home', icon: <HomeWorkIcon />, path: '/Inicio', roles: ['admin', 'usuario'] },
  { text: 'Consulta DGA', icon: <ListAltIcon />, path: '/ConsultaDga', roles: ['admin', 'usuario'] },
  { text: 'Registrar DGA', icon: <PostAddIcon />, path: '/RegistrarDga', roles: ['admin'] },
  { text: 'Administracion DGA', icon: <DashboardIcon />, path: '/GestionDga', roles: ['admin'] },
];

export default function SideBar() {
  const navigate = useNavigate();
  const { usuario, logout } = useContext(AuthContext);

  // Menú filtrado: si hay usuario se filtra por rol, si no hay se muestran opciones públicas
  const menuFiltrado = usuario
  ? menuItems.filter(item => item.roles.includes(usuario.rol))
  : [
      { text: 'Home', icon: <HomeWorkIcon />, path: '/Inicio' }
    ];

  return (

    <Box sx={{ flex: 1 }}>
    
       {/* Barra superior */}
      <AppBar position="fixed" sx={{ backgroundColor: APP_COLOR }}>
        <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>

          <img src={logo} alt="Logo" style={{ height: '58px', width: '190px' }} />
          {/* Texto centrado */}
          <Typography
            variant="h6"
            component="div"
            sx={{
              flexGrow: 1,
              textAlign: 'center',
              fontWeight: 'bold',
              letterSpacing: '1px'
            }}
          >
            DEPARTAMENTOS DE GESTION AMBIENTAL REGISTRADOS EN CVS
          </Typography>

          {/* Icono de Login / Logout */}
          {!usuario ? (
            <Tooltip title="Iniciar Sesión">
              <IconButton color="inherit" onClick={() => navigate('/login')}>
                <LockIcon sx={{ fontSize: '30px', color: '#f8f7f6ff' }}/>
              </IconButton>
            </Tooltip>
          ) : (
            <Tooltip title="Cerrar Sesión">
              <IconButton
                color="inherit"
                onClick={() => {
                  logout();
                  navigate('/login');
                }}
              >
                <LogoutIcon sx={{ fontSize: '30px', color: '#f9f8f7ff' }}/>
              </IconButton>
            </Tooltip>
          )}
        </Toolbar>
      </AppBar>

      {/* Cajón lateral */}
      <Drawer
        anchor="left"
        variant="permanent"
        sx={{
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { 
            width: DRAWER_WIDTH,
            boxSizing: 'border-box',
            marginTop: '64px', 
            backgroundColor: '#f5f5f5'
          },
        }}
      >
        {/* Encabezado */}
        <DrawerHeader>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%', p: 1 }}>
            {/* <img src={logo} alt="Logo" style={{ height: '55px', width: '50px' }} /> */}
            <PersonPinIcon sx={{ fontSize: '50px', color: '#252322ff' }}/>
            {usuario && (
              <Typography variant="body2" sx={{ mt: 1, fontWeight: 'bold' }}>
               {usuario.nombre_usuario}
              </Typography>
            )}
          </Box>
        </DrawerHeader>
        
        <Divider />

        {/* Menú principal */}
        <List>
          {menuFiltrado.map((item) => (
            <ListItem key={item.text} disablePadding>
              <MenuItemButton component={Link} to={item.path}>
                <ListItemIcon sx={{ color: PRIMARY_COLOR }}>
                  {React.cloneElement(item.icon, { sx: { fontSize: '27px' } })}
                </ListItemIcon>
                <ListItemText primary={item.text} primaryTypographyProps={{ fontSize: '15px' }} />
              </MenuItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>
     {/*  <Box
  component="footer"
    sx={{
      position: "fixed",
      bottom: 0,
      left: 0,
      width: "100%",
      backgroundColor: "#008FD1", // tu color corporativo
      color: "#fff",
      textAlign: "center",
      //py: 1,
      fontSize: "0.9rem",
      zIndex: 1200 // para que quede por encima de otros elementos
    }}
  >
  © {new Date().getFullYear()} CVS - Todos los derechos reservados
</Box> */}
    </Box>
    
  );
}
