import * as React from "react";
import Typography from "@mui/material/Typography";
import { Box } from "@mui/material";

export default function Footer() {
  return (
    <Box
      component="footer"
    >
      <Box
        component="footer"
         sx={{
          // position:"fixed",
            width: "100%",
            backgroundColor: "#008FD1",
            color: "#fff",
            textAlign: "center",
            py: 1,
            fontSize: "0.9rem"
        }}
      >
        © {new Date().getFullYear()} CVS - Todos los derechos reservados
      </Box>
    
    </Box>
  );
}