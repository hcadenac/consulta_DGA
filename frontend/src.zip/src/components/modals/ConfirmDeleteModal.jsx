import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  CircularProgress
} from '@mui/material';
import axios from 'axios';

const API_BASE_URL = 'http://localhost:3000'; // Asegúrate de tener esta constante si aplica

export const ConfirmDeleteModal = ({
  open,
  onClose,
  onConfirm, // Opcional si quieres hacer algo después de eliminar
  empresa, // Objeto con { id, nombre, ... }
  empresaNombre
}) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState(null);

  const handleConfirmDelete = async () => {
    if (!empresa || !empresaNombre) return;

    try {
      setIsDeleting(true);
      setDeleteError(null);
      await axios.delete(`http://localhost:3000/empresas/${empresaNombre}`);
      if (onConfirm) onConfirm(); // Para refrescar o actualizar datos en el padre
      onClose(); // Cierra el modal
    } catch (error) {
      console.error('Error al eliminar empresa:', error);
      setDeleteError(error.message);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Confirmar Eliminación</DialogTitle>
      <DialogContent>
        <DialogContentText>
          ¿Está seguro que desea eliminar la empresa <strong>{empresa}</strong>? 
          Esta acción no se puede deshacer.
        </DialogContentText>
        {deleteError && (
          <DialogContentText style={{ color: 'red' }}>
            Error: {deleteError}
          </DialogContentText>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={isDeleting}>
          Cancelar
        </Button>
        <Button
          onClick={handleConfirmDelete}
          color="error"
          disabled={isDeleting}
          startIcon={isDeleting ? <CircularProgress size={20} /> : null}
        >
          {isDeleting ? 'Eliminando...' : 'Eliminar'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
